### 部分接口
##### 首页购物中心-上区域
```
http://api.meituan.com/group/v1/deal/topic/discount/city/20?uuid=5C7B6342814C7B496D836A69C872202B5DE8DB689A2D777DFC717E10FC0B4271&msid=0FA91DDF-BF5B-4DA2-B05D-FA2032F30C6C2016-04-04-08-38594&utm_term=6.6&utm_source=AppStore&latlng=23.134643%2C113.373951&utm_content=5C7B6342814C7B496D836A69C872202B5DE8DB689A2D777DFC717E10FC0B4271&userid=160495643&utm_medium=iphone&movieBundleVersion=100&version_name=6.6&__skck=3c0cf64e4b039997339ed8fec4cddf05&__skua=5657981d60b5e2d83e9c64b453063ada&__skts=1459731016.429482&utm_campaign=AgroupBgroupD100H0&__skno=7486F945-8EC1-41B1-9EDC-C9562F04B760&__skcy=NR8eXbF1J1yURHvLvYJrgy3Wnhk%3D&ci=20&__vhost=api.mobile.meituan.com&client=iphone
```
```
{
	"stid": "720698155324449024",
	"data": [{
		"position": 0,
		"typeface_color": "#ff9900",
		"id": 7486,
		"share": {
			"message": "1元能吃肯德基",
			"url": "http://i.meituan.com/firework/kfchanbao"
		},
		"title": "1元能吃肯德基",
		"module": false,
		"maintitle": "1元肯德基",
		"tplurl": "imeituan://www.meituan.com/web?url=http://i.meituan.com/firework/kfchanbao",
		"type": 1,
		"imageurl": "http://p0.meituan.net/w.h/groupop/9aa35eed64db45aa33f9e74726c59d938450.png",
		"solds": 0,
		"deputytitle": "新用户专享"
	}, {
		"position": 0,
		"typeface_color": "#f6687d",
		"id": 15351,
		"share": {
			"message": "刷新颜值啦！领最高188元红包，更有疯狂立减ing～",
			"url": "http://i.meituan.com/firework/beautyactivity0328"
		},
		"title": "4月开春大促",
		"module": false,
		"maintitle": "领21元红包",
		"tplurl": "imeituan://www.meituan.com/web?url=http://i.meituan.com/firework/beautyactivity0328",
		"type": 1,
		"imageurl": "http://p0.meituan.net/w.h/groupop/b8fb2def2c0063c9acabed6cbf1c65449452.png",
		"solds": 0,
		"deputytitle": "小长假美美哒"
	}, {
		"position": 0,
		"typeface_color": "#6bbd00",
		"id": 15444,
		"share": {
			"message": "",
			"url": "http://i.meituan.com/firework/160115xinyonghu?activity_id=611"
		},
		"title": "外卖0401-0417刘莉君新客",
		"module": false,
		"maintitle": "新用户专享",
		"tplurl": "imeituan://www.meituan.com/web?url=http://i.meituan.com/firework/160115xinyonghu?activity_id=611",
		"type": 1,
		"imageurl": "http://p0.meituan.net/w.h/groupop/e1855577efd5280c905ab7a438b83f3d5000.png",
		"solds": 0,
		"deputytitle": "最高立减25元"
	}, {
		"position": 0,
		"typeface_color": "#06c1ae",
		"id": 15182,
		"share": {
			"message": "",
			"url": "http://mpay.meituan.com/resource/oneyuan/deal-list.html?entry=home#deal-list/"
		},
		"title": "一元抢吧",
		"module": false,
		"maintitle": "一元抢吧",
		"tplurl": "imeituan://www.meituan.com/web?url=http://mpay.meituan.com/resource/oneyuan/deal-list.html?entry=home#deal-list/",
		"type": 1,
		"imageurl": "http://p1.meituan.net/w.h/groupop/286f56222bac7bfd7462af56a64ce4a59032.png",
		"solds": 0,
		"deputytitle": "爆品抢到手软"
	}],
	"server": {
		"time": 1459731016
	},
	"paging": {
		"count": 5
	}
}
```



##### 首页购物中心
```
http://api.meituan.com/group/v1/shoppingmall/search?msid=0FA91DDF-BF5B-4DA2-B05D-FA2032F30C6C2016-04-04-08-38594&userid=160495643&__vhost=api.mobile.meituan.com&__skts=1459730301.927250&position=23.13728726012552%2C113.3684166102325&utm_term=6.6&__skno=6A1176A5-B1CF-45A3-AAB0-F4887F0B5649&limit=6&__skcy=IPSbkYKcHQHjpsH5vpnu7COMz8M%3D&ci=20&uuid=5C7B6342814C7B496D836A69C872202B5DE8DB689A2D777DFC717E10FC0B4271&utm_content=5C7B6342814C7B496D836A69C872202B5DE8DB689A2D777DFC717E10FC0B4271&utm_source=AppStore&utm_medium=iphone&version_name=6.6&accuracy=65&offset=0&__skck=3c0cf64e4b039997339ed8fec4cddf05&utm_campaign=AgroupBgroupD100H0&__skua=62de74921813448de74c487f3457db39

```
```
{
    "count": 4,
    "data": [
        {
            "detailurl": "imeituan://www.meituan.com/web/?url=http://i.meituan.com/shoppingmall/smDetail/4374715",
            "promotionIcon": "",
            "name": "正佳广场",
            "img": "http://p0.meituan.net/codeman/b4686ddc7270363868fcff917d3526cd37899.jpg",
            "showtext": {
                "text": "离我最近",
                "count": 84,
                "color": ""
            },
            "longitude": 113.327086,
            "latitude": 23.131909,
            "smid": 4374715,
            "promotionText": "送福利 商品低至1.5折"
        },
        {
            "detailurl": "imeituan://www.meituan.com/web/?url=http://i.meituan.com/shoppingmall/smDetail/50606658",
            "promotionIcon": "",
            "name": "白云万达广场",
            "img": "http://p0.meituan.net/codeman/c217fffcbf9b434844434a0acbdb434827837.jpg",
            "showtext": {
                "text": "55家优惠",
                "count": 55,
                "color": ""
            },
            "longitude": 113.26605,
            "latitude": 23.17151,
            "smid": 50606658,
            "promotionText": "春来花开 满100最高减60"
        },
        {
            "detailurl": "imeituan://www.meituan.com/web/?url=http://i.meituan.com/shoppingmall/smDetail/75813274",
            "promotionIcon": "",
            "name": "凯德广场●云尚",
            "img": "http://p0.meituan.net/codeman/2ad0711b7ffa9433bdc2577e7896082937607.jpg",
            "showtext": {
                "text": "61家优惠",
                "count": 61,
                "color": ""
            },
            "longitude": 113.269668,
            "latitude": 23.1818,
            "smid": 75813274,
            "promotionText": "新春送福利 购物满额有好礼"
        },
        {
            "detailurl": "imeituan://www.meituan.com/web/?url=http://i.meituan.com/shoppingmall/smDetail/41692498",
            "promotionIcon": "",
            "name": "来又来广场",
            "img": "http://p0.meituan.net/codeman/d675f4ad9b7ece9f0593db298beb082d31800.jpg",
            "showtext": {
                "text": "48家优惠",
                "count": 48,
                "color": ""
            },
            "longitude": 113.232008,
            "latitude": 23.397758,
            "smid": 41692498,
            "promotionText": "48家品牌优惠中：瑞可爷爷的店每满30减5，全单9折（买单立享）"
        }
    ],
    "tips": "全部4家",
    "jumpto": "imeituan://www.meituan.com/web/?url=http://i.meituan.com/shoppingmall/smList?sid=@geodist:asc"
}
```
#### 首页-热门频道
```

```
```
{
    "status": 1,
    "data": [
        {
            "entryid": 10001,
            "resource": {
                "cateArea": [
                    {
                        "id": 178,
                        "type": 1,
                        "mainTitle": "演出赛事",
                        "deputyTitle": "精彩不容错过",
                        "otherDesc": "HOT",
                        "topicId": 8761,
                        "entranceImgUrl": "http://p1.meituan.net/feop/f1f9d10251a05bfcbcbb5b7e647f24e022686.png",
                        "target": "imeituan://www.meituan.com/web?url=http://show.meituan.com"
                    },
                    {
                        "id": 607,
                        "type": 1,
                        "mainTitle": "汽车服务",
                        "deputyTitle": "洗车9.9元起",
                        "otherDesc": "HOT",
                        "topicId": 8763,
                        "entranceImgUrl": "http://p1.meituan.net/feop/2e0784031d8d22a8cb6d6461e33405b716269.png",
                        "target": "imeituan://www.meituan.com/web/search?url=http://i.meituan.com/auto"
                    },
                    {
                        "id": 1601,
                        "type": 1,
                        "mainTitle": "教育培训",
                        "deputyTitle": "1元get技能",
                        "otherDesc": "HOT",
                        "topicId": 20285,
                        "entranceImgUrl": "http://p0.meituan.net/feop/6c9fcecf6629b38c6a311564a2a988ed9346.png",
                        "target": "imeituan://www.meituan.com/web?url=http%3a%2f%2fm.dianping.com%2feducation%2fmt%2findex"
                    },
                    {
                        "id": 1615,
                        "type": 1,
                        "mainTitle": "火车/机票",
                        "deputyTitle": "下单赢手机",
                        "otherDesc": "HOT",
                        "topicId": 20066,
                        "entranceImgUrl": "http://p1.meituan.net/feop/ac19413541f81916c6259ae879d2acf418359.jpg",
                        "target": "imeituan://www.meituan.com/hotel/hybrid/web?url=http://i.meituan.com/trip/train/search/"
                    },
                    {
                        "id": 1447,
                        "type": 1,
                        "mainTitle": "结婚",
                        "deputyTitle": "婚纱照1折起",
                        "otherDesc": "HOT",
                        "topicId": 20178,
                        "entranceImgUrl": "http://p1.meituan.net/feop/c8f283d9ff32d28277128ed76dacd86d38141.png",
                        "target": "imeituan://www.meituan.com/deal/list?category_id=20178&group_category_id=20178"
                    },
                    {
                        "id": 183,
                        "type": 1,
                        "mainTitle": "亲子",
                        "deputyTitle": "游乐1折起",
                        "otherDesc": "HOT",
                        "topicId": 8766,
                        "entranceImgUrl": "http://p0.meituan.net/w.h/groupop/e7609c4c8c61d79e623681128c0c662845863.png",
                        "target": "imeituan://www.meituan.com/deal/list?type=poi&group_category_id=20007&category_id=20007"
                    },
                    {
                        "id": 184,
                        "type": 1,
                        "mainTitle": "儿童摄影",
                        "deputyTitle": "记录精彩瞬间",
                        "otherDesc": "HOT",
                        "topicId": 8767,
                        "entranceImgUrl": "http://p0.meituan.net/w.h/groupop/0a9fe6ae91e02a9b6bd2c7fd19d90aa522852.png",
                        "target": "imeituan://www.meituan.com/deal/list?group_category_id=398&category_id=398"
                    },
                    {
                        "id": 181,
                        "type": 1,
                        "mainTitle": "运动健身",
                        "deputyTitle": "不一样的自己",
                        "otherDesc": "HOT",
                        "topicId": 8764,
                        "entranceImgUrl": "http://p1.meituan.net/w.h/groupop/4a10f786f316fd5111a8a745d7eb9fc621675.png",
                        "target": "imeituan://www.meituan.com/deal/list?group_category_id=39&category_id=39"
                    }
                ],
                "topArea": {
                    "id": 1,
                    "type": 1,
                    "target": "imeituan://www.meituan.com/morecategory"
                }
            }
        }
    ],
    "server": {
        "time": 1459731016
    }
}
```


#### 首页-猜你喜欢
```
http://api.meituan.com/group/v2/recommend/homepage/city/20?userId=160495643&userid=160495643&__vhost=api.mobile.meituan.com&position=23.134643%2C113.373951&movieBundleVersion=100&utm_term=6.6&limit=40&wifi-mac=64%3A09%3A80%3A10%3A15%3A27&ci=20&__skcy=X6Jxu5SCaijU80yX5ioQuvCDKj4%3D&__skua=5657981d60b5e2d83e9c64b453063ada&__skts=1459731016.350255&wifi-name=Xiaomi_1526&client=iphone&uuid=5C7B6342814C7B496D836A69C872202B5DE8DB689A2D777DFC717E10FC0B4271&__skno=FEB757F5-6120-49EC-85B0-D1444A2C2E7B&utm_content=5C7B6342814C7B496D836A69C872202B5DE8DB689A2D777DFC717E10FC0B4271&utm_source=AppStore&utm_medium=iphone&version_name=6.6&wifi-cur=0&wifi-strength=&offset=0&utm_campaign=AgroupBgroupD100H0&__skck=3c0cf64e4b039997339ed8fec4cddf05&msid=0FA91DDF-BF5B-4DA2-B05D-FA2032F30C6C2016-04-04-08-38594
```
```
{
    "globalId": "c94bd869a9272adaafc2966811165698",
    "stid": "1585398200491662080_c0_ec94bd869a9272adaafc2966811165698",
    "stids": [
        {
            "stid": "1585398200491662080_c0_ec94bd869a9272adaafc2966811165698",
            "dealid": 31080046
        },
        {
            "stid": "288361507808977664_c1_ec94bd869a9272adaafc2966811165698",
            "dealid": 32281591
        },
        {
            "stid": "1585398200491662080_c2_ec94bd869a9272adaafc2966811165698",
            "dealid": 935987
        },
        {
            "stid": "1585398200491662080_c3_ec94bd869a9272adaafc2966811165698",
            "dealid": 30576874
        },
        {
            "stid": "288361507808977664_c4_ec94bd869a9272adaafc2966811165698",
            "dealid": 33822503
        },
        {
            "stid": "2089801358757171456_c5_ec94bd869a9272adaafc2966811165698",
            "dealid": 35022459
        },
        {
            "stid": "2089801358757171456_c6_ec94bd869a9272adaafc2966811165698",
            "dealid": 33576141
        },
        {
            "stid": "1585398200491662080_c7_ec94bd869a9272adaafc2966811165698",
            "dealid": 10231181
        },
        {
            "stid": "288361507808977664_c8_ec94bd869a9272adaafc2966811165698",
            "dealid": 32627430
        },
        {
            "stid": "288361507808977664_c9_ec94bd869a9272adaafc2966811165698",
            "dealid": 31462003
        },
        {
            "stid": "1585398200491662080_c10_ec94bd869a9272adaafc2966811165698",
            "dealid": 27247022
        },
        {
            "stid": "288361507808977664_c11_ec94bd869a9272adaafc2966811165698",
            "dealid": 28962370
        },
        {
            "stid": "288361507808977664_c12_ec94bd869a9272adaafc2966811165698",
            "dealid": 32819501
        },
        {
            "stid": "2089801358757171456_c13_ec94bd869a9272adaafc2966811165698",
            "dealid": 35073925
        },
        {
            "stid": "288361507808977664_c14_ec94bd869a9272adaafc2966811165698",
            "dealid": 30746384
        },
        {
            "stid": "1585398200491662080_c15_ec94bd869a9272adaafc2966811165698",
            "dealid": 26779241
        },
        {
            "stid": "2089801358757171456_c16_ec94bd869a9272adaafc2966811165698",
            "dealid": 29974162
        },
        {
            "stid": "288361507808977664_c17_ec94bd869a9272adaafc2966811165698",
            "dealid": 33349467
        },
        {
            "stid": "288361507808977664_c18_ec94bd869a9272adaafc2966811165698",
            "dealid": 32505883
        },
        {
            "stid": "2089801358757171456_c19_ec94bd869a9272adaafc2966811165698",
            "dealid": 36401002
        },
        {
            "stid": "288361507808977664_c20_ec94bd869a9272adaafc2966811165698",
            "dealid": 30775134
        },
        {
            "stid": "2089801358757171456_c21_ec94bd869a9272adaafc2966811165698",
            "dealid": 35059205
        },
        {
            "stid": "2089801358757171456_c22_ec94bd869a9272adaafc2966811165698",
            "dealid": 35971360
        },
        {
            "stid": "1585398200491662080_c23_ec94bd869a9272adaafc2966811165698",
            "dealid": 29884288
        },
        {
            "stid": "1585398200491662080_c24_ec94bd869a9272adaafc2966811165698",
            "dealid": 26061825
        },
        {
            "stid": "2089801358757171456_c25_ec94bd869a9272adaafc2966811165698",
            "dealid": 36295203
        },
        {
            "stid": "2089801358757171456_c26_ec94bd869a9272adaafc2966811165698",
            "dealid": 27076982
        },
        {
            "stid": "1585398200491662080_c27_ec94bd869a9272adaafc2966811165698",
            "dealid": 29120824
        },
        {
            "stid": "288361507808977664_c28_ec94bd869a9272adaafc2966811165698",
            "dealid": 29794318
        },
        {
            "stid": "288361507808977664_c29_ec94bd869a9272adaafc2966811165698",
            "dealid": 32192688
        },
        {
            "stid": "1585398200491662080_c30_ec94bd869a9272adaafc2966811165698",
            "dealid": 31703894
        },
        {
            "stid": "2089801358757171456_c31_ec94bd869a9272adaafc2966811165698",
            "dealid": 29547688
        },
        {
            "stid": "1585398200491662080_c32_ec94bd869a9272adaafc2966811165698",
            "dealid": 30107277
        },
        {
            "stid": "288361507808977664_c33_ec94bd869a9272adaafc2966811165698",
            "dealid": 36366269
        },
        {
            "stid": "1585398200491662080_c34_ec94bd869a9272adaafc2966811165698",
            "dealid": 26293932
        },
        {
            "stid": "2089801358757171456_c35_ec94bd869a9272adaafc2966811165698",
            "dealid": 653881
        },
        {
            "stid": "288361507808977664_c36_ec94bd869a9272adaafc2966811165698",
            "dealid": 33217009
        },
        {
            "stid": "2089801358757171456_c37_ec94bd869a9272adaafc2966811165698",
            "dealid": 26260285
        },
        {
            "stid": "2089801358757171456_c38_ec94bd869a9272adaafc2966811165698",
            "dealid": 27980939
        },
        {
            "stid": "288361507808977664_c39_ec94bd869a9272adaafc2966811165698",
            "dealid": 34084287
        }
    ],
    "ct_pois": [],
    "data": [
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/1473f29c9c78b2fdce7e08591a39e307117960.jpg",
            "imageTag": "3",
            "title": "华莱士",
            "subTitle": "[华景新城等] 汉堡+小薯条+中可乐1份",
            "mainMessage": "¥",
            "mainMessage2": "9.9",
            "subMessage": "门市价:¥19",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售66740",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "31080046",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"specialCondition\":\"备注：华莱士（建设路店）、华莱士（英德兴发店）、华莱士（阳山店）、华莱士（番禺新沙店）于2016年2月6日—2月22日不可使用团购券；华莱士（天河长福店）于2016年2月3日—2月19日不可使用团购券；\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "单人套餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c0_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/088247aeb7f3da852699f37e5e162b39368260.jpg",
            "imageTag": "3",
            "title": "超润糖水",
            "subTitle": "[华景新城] 甜品10选1，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "8.8",
            "subMessage": "门市价:¥12",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售7",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "32281591",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "广东特色糖水单人"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c1_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/201207/31/0802_0731161210.jpg",
            "imageTag": "0",
            "title": "皇冠 • 玛莉奥",
            "subTitle": "[华景新城等] 20元的面包代金劵，节假日通用",
            "mainMessage": "¥",
            "mainMessage2": "15.8",
            "subMessage": "门市价:¥20",
            "topRightInfo": "650m",
            "bottomRightInfo": "已售301851",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "935987",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c2_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/8fdcdab80fb699952c0a36193bd1a0d166539.jpg",
            "imageTag": "3",
            "title": "肯德基",
            "subTitle": "[天河公园/上社等] 1元能吃肯德基【新用户专享】",
            "mainMessage": "¥",
            "mainMessage2": "1",
            "subMessage": "门市价:¥16",
            "topRightInfo": "695m",
            "bottomRightInfo": "已售280972",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "30576874",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "汉堡套餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c3_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/3ea536e2372d8e3025b8b032b13c819b36316.jpg",
            "imageTag": "3",
            "title": "福一通信",
            "subTitle": "[天河公园/上社等] 中国移动广东移动用户移动流量充值200m1次，本店内还有10M、20M、30M、50M、70M、",
            "mainMessage": "¥",
            "mainMessage2": "9.3",
            "subMessage": "门市价:¥30",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售1998",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "33822503",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "group",
                "iUrl": "",
                "cate": "3",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c4_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/dpdeal/fb55a344fe1e50ae576165335844badd117574.jpg",
            "imageTag": "0",
            "title": "跑马场佰音KTV",
            "subTitle": "[跑马场] 单人周一到周日11：30-20:00任选3小时欢唱+自助餐",
            "mainMessage": "¥",
            "mainMessage2": "45",
            "subMessage": "",
            "campaign": {
                "tag": "立减5元",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "3.2km",
            "bottomRightInfo": "已售181056",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "35022459",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "ktv",
                "iUrl": "",
                "cate": "",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c5_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/7745f7bdbce373c20de45156cf54a0d183181.jpg@117_0_468_468a%7C267h_267w_2e_100q",
            "imageTag": "0",
            "title": "牛8公馆",
            "subTitle": "[麓湖公园周边] 四人飘香牛杂火锅1份",
            "mainMessage": "¥",
            "mainMessage2": "88",
            "subMessage": "",
            "campaign": {
                "tag": "立减87元",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "8.8km",
            "bottomRightInfo": "已售8539",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "33576141",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2016-02-14\",\"startDate\":\"2016-02-06\",\"useDay\":\"1\"}",
                    "81": "飘香牛杂火锅"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c6_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/__41343724__6245449.jpg",
            "imageTag": "3",
            "title": "尊宝比萨",
            "subTitle": "[华景新城等] 二人餐",
            "mainMessage": "¥",
            "mainMessage2": "68",
            "subMessage": "门市价:¥94",
            "topRightInfo": "723m",
            "bottomRightInfo": "已售664895",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "10231181",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "二人餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c7_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/9a1681bf117a9233d1bec86e17334c94113586.jpg",
            "imageTag": "3",
            "title": "糖雅心港式甜品店",
            "subTitle": "[华景新城] 20元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "18.9",
            "subMessage": "门市价:¥20",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售3",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "32627430",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c8_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/b10846de40097f652f76c1ddd238358b43594.jpg",
            "imageTag": "3",
            "title": "可可司",
            "subTitle": "[华景新城] 饮品6选1，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "7.5",
            "subMessage": "门市价:¥9",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售4",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "31462003",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "酸果多多1人饮"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c9_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/f46493e814d09364604f50ef426456f990221.jpg",
            "imageTag": "3",
            "title": "弗兰德",
            "subTitle": "[棠下等] 超值汉堡单人餐，有赠品",
            "mainMessage": "¥",
            "mainMessage2": "9",
            "subMessage": "门市价:¥16",
            "topRightInfo": "830m",
            "bottomRightInfo": "已售17577",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "27247022",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "超值汉堡单人餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c10_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/409ac7386c9c5bd6d68f5bc601562131124637.jpg",
            "imageTag": "3",
            "title": "锅将军正宗桂林米粉",
            "subTitle": "[华景新城] 正宗双拼粉（腐竹、鸡蛋、鸡爪、鸭爪可任选一种搭配）1份",
            "mainMessage": "¥",
            "mainMessage2": "11",
            "subMessage": "门市价:¥14",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售537",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "28962370",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "正宗双拼粉"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c11_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/75744f21ebfc4f144b3d21b17e8c16b9135241.jpg",
            "imageTag": "3",
            "title": "潮妈浏阳蒸菜",
            "subTitle": "[华景新城] 15元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "13",
            "subMessage": "门市价:¥15",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售83",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "32819501",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c12_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/dpdeal/97435d83274b73f3d2272da540e27b46123978.jpg",
            "imageTag": "0",
            "title": "畅响KTV",
            "subTitle": "[华景新城] 周一至周日13:00-19:00时段任选3小时欢唱券",
            "mainMessage": "¥",
            "mainMessage2": "9.9",
            "subMessage": "门市价:¥188",
            "topRightInfo": "767m",
            "bottomRightInfo": "已售996",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "35073925",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "ktv",
                "iUrl": "",
                "cate": "",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c13_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/fea882ce333d95b4d04249f6093acc4540129.jpg",
            "imageTag": "3",
            "title": "华旗安然纳米汗蒸馆",
            "subTitle": "[华景新城] 安然纳米养生汗蒸，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "28.8",
            "subMessage": "门市价:¥58",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售170",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "30746384",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "group",
                "iUrl": "",
                "cate": "2",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c14_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/842b16beadff89f89935f0c975ca8a77102198.jpg",
            "imageTag": "3",
            "title": "紫燕百味鸡",
            "subTitle": "[棠下等] 20元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "19.6",
            "subMessage": "门市价:¥20",
            "topRightInfo": "689m",
            "bottomRightInfo": "已售67957",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "26779241",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2016-02-14\",\"startDate\":\"2016-02-07\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c15_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/dfda4e55af4663d515baa145527d4b3533351.jpg",
            "imageTag": "3",
            "title": "桃园明宴",
            "subTitle": "[跑马场] 精美茶点，建议2人使用",
            "mainMessage": "¥",
            "mainMessage2": "56",
            "subMessage": "门市价:¥156",
            "topRightInfo": "3.2km",
            "bottomRightInfo": "已售27026",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "29974162",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2016-04-04\",\"startDate\":\"2016-04-04\",\"useDay\":\"1\"}",
                    "81": "精美茶点"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c16_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/945e3d1b490dc5f224cb6d3a4458e1b0110063.jpg",
            "imageTag": "3",
            "title": "麻辣香锅",
            "subTitle": "[华景新城] 20元代金券1张，可叠加2张",
            "mainMessage": "¥",
            "mainMessage2": "18",
            "subMessage": "门市价:¥20",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售18",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "33349467",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c17_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/bf20d92426ddfe5f631370d1900183ad352076.jpg",
            "imageTag": "3",
            "title": "80后烤场",
            "subTitle": "[天河公园/上社] 100元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "88",
            "subMessage": "门市价:¥100",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售17",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "32505883",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c18_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/9ab23e611587a0c0451e99d4ac3e588f37189.jpg@133_0_533_533a%7C267h_267w_2e_90q",
            "imageTag": "3",
            "title": "0101cafe",
            "subTitle": "[正佳广场] 甜品3选1，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "29.9",
            "subMessage": "",
            "campaign": {
                "tag": "立减15元",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "4.8km",
            "bottomRightInfo": "已售3906",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "36401002",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "雪花冰单人餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c19_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/975456444bb10d710a5fd03e9d043d8283061.jpg",
            "imageTag": "3",
            "title": "客家面馆",
            "subTitle": "[华景新城] 美味客家面单人餐",
            "mainMessage": "¥",
            "mainMessage2": "10.9",
            "subMessage": "门市价:¥12",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售312",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "30775134",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "美味客家面单人餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c20_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/dpdeal/13ea93e286317fc7df28d96c792aef7f78542.jpg",
            "imageTag": "0",
            "title": "K歌王(天河东路店)",
            "subTitle": "[体育中心] 周一至周日 11:00-20:30单人欢唱3小时+自助餐",
            "mainMessage": "¥",
            "mainMessage2": "41",
            "subMessage": "",
            "campaign": {
                "tag": "立减5元",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "4.2km",
            "bottomRightInfo": "已售6189",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "35059205",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "ktv",
                "iUrl": "",
                "cate": "",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c21_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/0cff4a60bfaf186a769fbc0445379aa038488.jpg",
            "imageTag": "3",
            "title": "万岁寿司",
            "subTitle": "[东圃等] 100元代金券1张，可叠加50张",
            "mainMessage": "¥",
            "mainMessage2": "88",
            "subMessage": "",
            "campaign": {
                "tag": "立减18",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "3.3km",
            "bottomRightInfo": "已售57181",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "35971360",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c22_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/751f8f301ee826acad518e41774bb84831894.jpg",
            "imageTag": "3",
            "title": "贡茶",
            "subTitle": "[天河公园/上社等] 饮品6选1，免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "11.9",
            "subMessage": "门市价:¥17",
            "topRightInfo": "1.2km",
            "bottomRightInfo": "已售28351",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "29884288",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "精选招牌奶茶"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c23_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/4b3bad1e6d3d9d0f212ebf8f64d7881724648.jpg",
            "imageTag": "3",
            "title": "蒙自源",
            "subTitle": "[棠下等] 全天双人餐",
            "mainMessage": "¥",
            "mainMessage2": "36",
            "subMessage": "门市价:¥54",
            "topRightInfo": "1.2km",
            "bottomRightInfo": "已售268858",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "26061825",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "全天双人餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c24_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/effae2a58891e528738ea6d8321eb386195484.jpg@190_0_761_761a%7C267h_267w_2e_90q",
            "imageTag": "3",
            "title": "豪客来",
            "subTitle": "[天河公园/上社等] 100元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "96",
            "subMessage": "",
            "campaign": {
                "tag": "立减8元",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "1.5km",
            "bottomRightInfo": "已售24596",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "36295203",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c25_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/3aca140603bff2ebb1eaa14548d0625564615.jpg",
            "imageTag": "3",
            "title": "金上阪韩式自助烤肉▪火锅▪寿司",
            "subTitle": "[华景新城] 晚餐自助烤肉火锅，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "55",
            "subMessage": "",
            "campaign": {
                "tag": "立减18",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "702m",
            "bottomRightInfo": "已售20112",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "27076982",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "晚餐自助烤肉火锅"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c26_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/3dc51032a4a92ef6e7772d2c5c0b7db938017.jpg",
            "imageTag": "3",
            "title": "中山大鸽饭",
            "subTitle": "[棠下等] 100元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "92",
            "subMessage": "门市价:¥100",
            "topRightInfo": "1.0km",
            "bottomRightInfo": "已售50712",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "29120824",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2016-01-03\",\"specialCondition\":\"国家法定 节假日不可用\",\"startDate\":\"2016-01-01\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c27_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/a53e22dfd1046a4bad80c2b0fbb18857109911.jpg",
            "imageTag": "3",
            "title": "陈记甜点",
            "subTitle": "[华景新城] 招牌清补凉1份，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "9",
            "subMessage": "门市价:¥10",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售27",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "29794318",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "招牌清补凉"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c28_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/66eb54e9148e044762c097ed00cf858c31697.jpg",
            "imageTag": "3",
            "title": "眼之悦眼镜",
            "subTitle": "[天河公园/上社] 288防蓝光套餐，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "288",
            "subMessage": "门市价:¥768",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售2",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "32192688",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "group",
                "iUrl": "",
                "cate": "3",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"specialCondition\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c29_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/7ee5dc7d23c2eb9966b90adbb9609cff29657.jpg",
            "imageTag": "3",
            "title": "御可贡茶",
            "subTitle": "[华景新城] 饮品6选1，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "12.8",
            "subMessage": "门市价:¥16",
            "topRightInfo": "650m",
            "bottomRightInfo": "已售1636",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "31703894",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "特饮贡茶单人餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c30_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/52fb712c2947a56e25338f7d4a16c135152605.jpg",
            "imageTag": "3",
            "title": "自由空间餐厅酒吧",
            "subTitle": "[石牌/百脑汇] 100元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "59.9",
            "subMessage": "门市价:¥100",
            "topRightInfo": "3.1km",
            "bottomRightInfo": "已售42380",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "29547688",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2015-12-25,2016-02-14\",\"startDate\":\"2015-12-24,2016-02-07\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c31_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/f1f75d3b5a7c85d620542665854ee0f236200.jpg",
            "imageTag": "3",
            "title": "面点王",
            "subTitle": "[棠下等] 30元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "28",
            "subMessage": "",
            "campaign": {
                "tag": "多优惠+",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "1.1km",
            "bottomRightInfo": "已售21256",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "30107277",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2015-09-27,2015-10-07\",\"startDate\":\"2015-09-26,2015-10-01\",\"useDay\":\"1\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c32_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/94d95048db4e32f7bb2f3746d26a2a1123762.jpg",
            "imageTag": "3",
            "title": "地下铁",
            "subTitle": "[天河公园/上社] 饮品5选1，建议单人使用，提供免费WiFi，滋味鲜美，邀您品鉴",
            "mainMessage": "¥",
            "mainMessage2": "8.8",
            "subMessage": "门市价:¥64",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售2",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "36366269",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c33_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/1943e35c38ba3a466cd45ca18cd495f039119.jpg",
            "imageTag": "3",
            "title": "龚记牛骨牛杂屋",
            "subTitle": "[华景新城等] 100元代金券1张，可叠加",
            "mainMessage": "¥",
            "mainMessage2": "90",
            "subMessage": "门市价:¥100",
            "topRightInfo": "609m",
            "bottomRightInfo": "已售8287",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "26293932",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2016-02-12\",\"startDate\":\"2016-02-08\",\"useDay\":\"0\",\"weekday\":\"6,7\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "1585398200491662080_c34_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/ee8847ad7cbd312d44c4ea70b2a2c82e108261.jpg",
            "imageTag": "0",
            "title": "长隆欢乐世界特惠门票1张",
            "subTitle": "[番禺区] 长隆欢乐世界特惠门票1张",
            "mainMessage": "¥",
            "mainMessage2": "205",
            "subMessage": "",
            "campaign": {
                "tag": "减13元",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "15.3km",
            "bottomRightInfo": "已售106017",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "653881",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "trip",
                "iUrl": "",
                "cate": "2,78",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2014-05-03,2014-06-02\",\"startDate\":\"2014-05-01,2014-05-31\",\"useDay\":\"1\"}",
                    "575": "{\"key\":\"MP\"}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c35_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/__32963630__1878964.jpg",
            "imageTag": "0",
            "title": "文星连锁酒店",
            "subTitle": "[华景新城等] 钟点房4小时，钟点房双床房/钟点房大床房2选1，免费WIFI，交通便利，环境优雅。",
            "mainMessage": "¥",
            "mainMessage2": "68",
            "subMessage": "",
            "campaign": {
                "tag": "返券",
                "festival": "",
                "color": "",
                "shortTag": ""
            },
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售15474",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "33217009",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "hotel",
                "iUrl": "",
                "cate": "20",
                "optionalattrs": {
                    "1": "MPT,MPO",
                    "2": "HR",
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "38": "{\"key\":\"HR\",\"label\":{\"hourCount\":\"4\",\"number\":\"\"},\"template\":{\"DR\":\"过夜房，可入住{number}晚\",\"HR\":\"钟点房，{hourCount}小时\"}}"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c36_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/06bc4290d5b023d7b9c4ca7129c2433321526.jpg@120_0_400_400a%7C267h_267w_2e_100q",
            "imageTag": "3",
            "title": "點都德",
            "subTitle": "[岗顶/龙口等] 100元代金券1张，全场通用",
            "mainMessage": "¥",
            "mainMessage2": "88",
            "subMessage": "门市价:¥100",
            "topRightInfo": "3.5km",
            "bottomRightInfo": "已售296706",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "26260285",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"2016-02-22,2016-04-04\",\"specialCondition\":\"2016.2.3\",\"startDate\":\"2016-02-04,2016-04-02\",\"useDay\":\"0\",\"weekday\":\"6,7\"}",
                    "13": "1"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c37_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p1.meituan.net/w.h/deal/141dcad42194f29a9a1613efded19a15127150.jpg",
            "imageTag": "3",
            "title": "蒙肥羊",
            "subTitle": "[石牌/百脑汇] 全天通用自助餐，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "63",
            "subMessage": "门市价:¥68",
            "topRightInfo": "3.5km",
            "bottomRightInfo": "已售162237",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "27980939",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "全天通用自助餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "2089801358757171456_c38_ec94bd869a9272adaafc2966811165698"
        },
        {
            "imageUrl": "http://p0.meituan.net/w.h/deal/8cd684a8cdc702218645750fa693f5f535137.jpg@0_6_640_387a%7C388h_640w_2e_100q",
            "imageTag": "3",
            "title": "生米熟饭",
            "subTitle": "[天河公园/上社] 明炉烧鸭饭1份，提供免费WiFi",
            "mainMessage": "¥",
            "mainMessage2": "9.8",
            "subMessage": "门市价:¥10",
            "topRightInfo": "<500m",
            "bottomRightInfo": "已售1",
            "_type": "deal",
            "_from": "DEAL_GROUP",
            "_id": "34084287",
            "_iUrl": "",
            "_jumpNeed": {
                "channel": "food",
                "iUrl": "",
                "cate": "1",
                "optionalattrs": {
                    "11": "{\"endDate\":\"\",\"startDate\":\"\",\"useDay\":\"1\"}",
                    "81": "套餐"
                }
            },
            "color": {
                "mainMessage": "#06c1ae",
                "subTitle": "#999999",
                "title": "#333333",
                "mainMessage2": "#06c1ae",
                "subMessage": "#999999",
                "topRightInfo": "#999999",
                "bottomRightInfo": "#999999"
            },
            "stid": "288361507808977664_c39_ec94bd869a9272adaafc2966811165698"
        }
    ],
    "serverInfo": {
        "cost_groupContext": 20,
        "useV1": false,
        "traceId": "924c943e-7720-421d-8e52-e9d86dc1d5d1",
        "cost_campaign": 49,
        "cost_dealService": 21
    }
}
```





